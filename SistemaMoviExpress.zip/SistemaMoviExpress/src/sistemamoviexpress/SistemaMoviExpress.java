package sistemamoviexpress;

import java.util.Scanner;

// Clase base
class Vehiculo {
    protected String identificador;
    protected String marca;
    protected String modelo;
    protected double kilometraje;

    public Vehiculo(String identificador, String marca, String modelo, double kilometraje) {
        this.identificador = identificador;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometraje = kilometraje;
    }

    public void mostrarInformacion() {
        System.out.println("Identificador: " + identificador);
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Kilometraje: " + kilometraje + " km");
    }

    public double calcularMantenimiento() {
        return 0;
    }
}

// Clase derivada Automovil
class Automovil extends Vehiculo {

    private int numeroPuertas;
    private final double COSTO_POR_KM = 0.09;

    public Automovil(String identificador, String marca, String modelo,
                     double kilometraje, int numeroPuertas) {

        super(identificador, marca, modelo, kilometraje);
        this.numeroPuertas = numeroPuertas;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Tipo: Automóvil");
        super.mostrarInformacion();
        System.out.println("Número de puertas: " + numeroPuertas);
    }

    @Override
    public double calcularMantenimiento() {
        return kilometraje * COSTO_POR_KM;
    }
}

// Clase derivada Motocicleta
class Motocicleta extends Vehiculo {

    private int cilindrada;
    private final double COSTO_POR_KM = 0.07;

    public Motocicleta(String identificador, String marca, String modelo,
                       double kilometraje, int cilindrada) {

        super(identificador, marca, modelo, kilometraje);
        this.cilindrada = cilindrada;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Tipo: Motocicleta");
        super.mostrarInformacion();
        System.out.println("Cilindrada: " + cilindrada + " cc");
    }

    @Override
    public double calcularMantenimiento() {
        return kilometraje * COSTO_POR_KM;
    }
}

// Clase principal
public class SistemaMoviExpress {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("===== SISTEMA MOVIEXPRESS =====");

        // Datos del automóvil
        System.out.println("\nAUTOMÓVIL");

        System.out.print("Identificador: ");
        String idAuto = teclado.nextLine();

        System.out.print("Marca: ");
        String marcaAuto = teclado.nextLine();

        System.out.print("Modelo: ");
        String modeloAuto = teclado.nextLine();

        System.out.print("Kilometraje: ");
        double kmAuto = teclado.nextDouble();

        System.out.print("Número de puertas: ");
        int puertas = teclado.nextInt();

        teclado.nextLine();

        // Datos de la motocicleta
        System.out.println("\nMOTOCICLETA");

        System.out.print("Identificador: ");
        String idMoto = teclado.nextLine();

        System.out.print("Marca: ");
        String marcaMoto = teclado.nextLine();

        System.out.print("Modelo: ");
        String modeloMoto = teclado.nextLine();

        System.out.print("Kilometraje: ");
        double kmMoto = teclado.nextDouble();

        System.out.print("Cilindrada: ");
        int cilindrada = teclado.nextInt();

        Vehiculo auto = new Automovil(
                idAuto, marcaAuto, modeloAuto, kmAuto, puertas);

        Vehiculo moto = new Motocicleta(
                idMoto, marcaMoto, modeloMoto, kmMoto, cilindrada);

        System.out.println("\n===== DATOS DE VEHÍCULOS =====");

        auto.mostrarInformacion();
        System.out.printf("Costo de mantenimiento: $%.2f MXN%n%n",
                auto.calcularMantenimiento());

        moto.mostrarInformacion();
        System.out.printf("Costo de mantenimiento: $%.2f MXN%n",
                moto.calcularMantenimiento());

        teclado.close();
    }
}